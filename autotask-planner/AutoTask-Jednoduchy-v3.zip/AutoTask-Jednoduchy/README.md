# AutoTask – jednoduchá verze (v3)

Otevřete opportunity → spusťte nástroj → zadejte jeden nebo víc tasků → **Vytvořit**.

* Product se **předvybere podle produktu v opportunity** (z Products / z názvu opty). Označené ★ jsou produkty z opty, můžete vybrat jiný.
* U každého tasku zadáte **název**, datum, kategorii a typ (podle `Customer_Interaction_Task_List`), Product a Audience.
* Tlačítko **＋ Přidat další task** přidá další task (zkopíruje poslední nastavení, název si dáte vlastní).
* Status = Completed, Priority = Normal, Assigned To = vy, formát data `DD.MM.YYYY`.
* Během vytváření se panel zmenší do rohu, aby bylo vidět formulář Salesforce. **■ Stop** zastaví po aktuálním tasku.
* Dole je **Log** a **Kopírovat log** pro případ potíží.

Starší, složitější verze (průvodce, více opt, plánování týdnů) je ve složce `plna-verze/`.

## Spuštění
Viz `0-CIST-NEJDRIV.txt`.

## Vývoj
`python3 build.py` sestaví jednoduchou verzi do `dist/`, `python3 build.py full` plnou do `dist-full/`. Zdroje: `src/engine.js` (ovládání formuláře), `src/ui-simple.js`, `src/ui-full.js`.
